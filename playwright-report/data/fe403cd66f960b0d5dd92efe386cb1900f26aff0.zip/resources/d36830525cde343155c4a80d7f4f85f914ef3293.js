(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__04kpziu._.css","static/chunks/_0_oruqe._.js","static/chunks/node_modules_12trhs6._.js","static/chunks/src_app_login_page_tsx_1cddrpa._.js"],
    source: "entry"
});
